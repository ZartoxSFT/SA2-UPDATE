@echo off
rem The Java 17 shipped in the java folder first, the PC's own Java otherwise.
if exist "%~dp0java\bin\javaw.exe" (
    start "" "%~dp0java\bin\javaw.exe" -jar "%~dp0SA2Online.jar"
    exit /b 0
)
where javaw >nul 2>nul || (echo Java 17 ou plus est necessaire : https://adoptium.net & pause & exit /b 1)
start "" javaw -jar "%~dp0SA2Online.jar"
